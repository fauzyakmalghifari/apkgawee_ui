package com.example.apkgawee.apkgawee

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
