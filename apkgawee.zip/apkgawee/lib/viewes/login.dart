import 'package:apkgawee/viewes/constraint.dart';
import 'package:apkgawee/viewes/home.dart' hide kPrimaryColor, kLightPurple, kDefaultPadding;
import 'package:apkgawee/viewes/registrasi.dart';
import 'package:flutter/material.dart';

class LoginScreen extends StatefulWidget {
  final String userType;

  const LoginScreen({super.key, required this.userType});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  // Gunakan 'JOB SEEKER' atau 'COMPANY' sebagai konstanta string
  static const String _jobSeeker = 'JOB SEEKER';
  static const String _company = 'COMPANY';

  String _currentType = _jobSeeker;

  // Controller untuk input
  final TextEditingController _usernameController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  final TextEditingController _companyIdController = TextEditingController();

  @override
  void initState() {
    super.initState();
    // Inisialisasi tipe berdasarkan widget.userType
    _currentType = widget.userType.toUpperCase().contains('COMPANY') ? _company : _jobSeeker;
  }

  @override
  void dispose() {
    // Bersihkan controller saat state dibuang
    _usernameController.dispose();
    _passwordController.dispose();
    _companyIdController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kLightPurple, // Menggunakan kLightPurple
      appBar: AppBar(
        backgroundColor: kLightPurple, // Menggunakan kLightPurple
        elevation: 0,
        toolbarHeight: 0,
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(kDefaultPadding), // Menggunakan kDefaultPadding
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: <Widget>[
              const SizedBox(height: 20),
              // Logo Aplikasi
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(
                    Icons.business_center_outlined,
                    size: 35,
                    color: kPrimaryColor, // Menggunakan kPrimaryColor
                  ),
                  const SizedBox(width: 8),
                  const Text(
                    'Gawee',
                    style: TextStyle(
                      fontSize: 30,
                      fontWeight: FontWeight.bold,
                      color: Colors.black87,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 30),

              // Pilihan Tipe Pengguna (Job Seeker / Company)
              Row(
                children: [
                  Expanded(
                    child: _buildTypeTab(_jobSeeker),
                  ),
                  Expanded(
                    child: _buildTypeTab(_company),
                  ),
                ],
              ),
              const SizedBox(height: 20),

              // Teks Utama
              const Text(
                'Sign in to your registered account',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                  color: Colors.black87,
                ),
              ),
              const SizedBox(height: 30),

              // 🌟 Field Input Company ID (Hanya Tampil untuk Company)
              if (_currentType == _company) ...[
                TextFormField(
                  controller: _companyIdController,
                  decoration: InputDecoration(
                    hintText: 'Company ID',
                    filled: true,
                    fillColor: Colors.white,
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10),
                      borderSide: BorderSide.none,
                    ),
                    contentPadding: const EdgeInsets.symmetric(horizontal: 20, vertical: 18),
                  ),
                ),
                const SizedBox(height: 15),
              ],

              // Field Input User Name
              TextFormField(
                controller: _usernameController,
                decoration: InputDecoration(
                  hintText: 'User Name',
                  filled: true,
                  fillColor: Colors.white,
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10),
                    borderSide: BorderSide.none,
                  ),
                  contentPadding: const EdgeInsets.symmetric(horizontal: 20, vertical: 18),
                ),
              ),
              const SizedBox(height: 15),

              // Field Input Password
              TextFormField(
                controller: _passwordController,
                obscureText: true,
                decoration: InputDecoration(
                  hintText: 'Password',
                  filled: true,
                  fillColor: Colors.white,
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10),
                    borderSide: BorderSide.none,
                  ),
                  contentPadding: const EdgeInsets.symmetric(horizontal: 20, vertical: 18),
                ),
              ),
              const SizedBox(height: 25),

              // Tombol LOGIN
              ElevatedButton(
                onPressed: () {
                  // Aksi Login
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => HomeScreen()),
                  );
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: kPrimaryColor, // Menggunakan kPrimaryColor
                  padding: const EdgeInsets.symmetric(vertical: 15),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                ),
                child: const Text(
                  'LOGIN',
                  style: TextStyle(
                    fontSize: 18,
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
              const SizedBox(height: 20),

              // Lupa Password
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Text(
                    'Forgot your password? ',
                    style: TextStyle(color: Colors.black54),
                  ),
                  GestureDetector(
                    onTap: () {
                      // Aksi reset password
                    },
                    child: Text(
                      'Reset here',
                      style: TextStyle(
                        color: kPrimaryColor, // Menggunakan kPrimaryColor
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 30),

              // Opsi Sign In dengan (Menggunakan Ikon & Link)
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Text('Or sign in with'),
                  const SizedBox(width: 15),
                  // Ikon Google
                  Image.network(
                    'https://img.icons8.com/color/48/google-logo.png',
                    width: 30,
                    height: 30,
                    loadingBuilder: (context, child, loadingProgress) {
                      if (loadingProgress == null) return child;
                      return const SizedBox(width: 30, height: 30, child: Center(child: CircularProgressIndicator(strokeWidth: 2)));
                    },
                    errorBuilder: (context, error, stackTrace) => const Icon(Icons.g_mobiledata, size: 30, color: Colors.blue),
                  ),
                  const SizedBox(width: 15),
                  // Ikon Facebook
                  Image.network(
                    'https://img.icons8.com/fluency/48/facebook-new.png',
                    width: 30,
                    height: 30,
                    loadingBuilder: (context, child, loadingProgress) {
                      if (loadingProgress == null) return child;
                      return const SizedBox(width: 30, height: 30, child: Center(child: CircularProgressIndicator(strokeWidth: 2)));
                    },
                    errorBuilder: (context, error, stackTrace) => const Icon(Icons.facebook, size: 30, color: Colors.blue),
                  ),
                ],
              ),
              const SizedBox(height: 40),

              // Tombol CREATE ACCOUNT
              OutlinedButton(
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => const RegistrationScreen()),
                  );
                },
                style: OutlinedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(vertical: 15),
                  side: const BorderSide(color: kPrimaryColor, width: 1.5), // Menggunakan kPrimaryColor
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                ),
                child: const Text(
                  'CREATE ACCOUNT',
                  style: TextStyle(
                    fontSize: 18,
                    color: kPrimaryColor, // Menggunakan kPrimaryColor
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
              const SizedBox(height: 20),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildTypeTab(String type) {
    bool isSelected = _currentType == type;

    return GestureDetector(
      onTap: () {
        setState(() {
          _currentType = type;
        });
      },
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 10),
        decoration: BoxDecoration(
          border: Border(
            bottom: BorderSide(
              color: isSelected ? kPrimaryColor : Colors.transparent, // Menggunakan kPrimaryColor
              width: 3.0,
            ),
          ),
        ),
        child: Text(
          type,
          textAlign: TextAlign.center,
          style: TextStyle(
            color: isSelected ? kPrimaryColor : Colors.black54, // Menggunakan kPrimaryColor
            fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
            fontSize: 15,
          ),
        ),
      ),
    );
  }
}